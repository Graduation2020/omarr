package com.example.myapplication;


import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Patterns;
import android.view.ContextThemeWrapper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;



public class AddAdminFragment extends Fragment {


    public AddAdminFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // create ContextThemeWrapper from the original Activity Context with the custom theme
        final Context contextThemeWrapper = new ContextThemeWrapper(getActivity(), R.style.AppTheme_Dark);

        // clone the inflater using the ContextThemeWrapper
        LayoutInflater localInflater = inflater.cloneInContext(contextThemeWrapper);

        // Inflate the layout for this fragment
        final View view =  localInflater.inflate(R.layout.fragment_add_admin, container, false);
        final DatabaseHelper databaseHelper=new DatabaseHelper(getActivity());

        final EditText firstName=(EditText)view.findViewById(R.id.firstNameFragment);
        final EditText lastName=(EditText)view.findViewById(R.id.lastNameFragment);
        final Spinner gender=(Spinner) view.findViewById(R.id.genderFragment);
        final EditText email=(EditText)view.findViewById(R.id.emailFragment);
        final EditText phone=(EditText)view.findViewById(R.id.mobileFragment);
        final EditText password=(EditText)view.findViewById(R.id.passwordFragment);
        final EditText confirmPassword=(EditText)view.findViewById(R.id.confirmPasswordFragment);
        String[] options = { "Male", "Female"};
        ArrayAdapter objGenderArr = new ArrayAdapter(getActivity(),android.R.layout.simple_spinner_item, options);
        gender.setAdapter(objGenderArr);
        final Button createAccount = (Button)view.findViewById(R.id.button_sgnupFragment);
        createAccount.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (!validate(view)) {

                    return;
                }




                User user =new User();
                user.setFirstName(firstName.getText().toString().trim());
                user.setLastName(lastName.getText().toString().trim());
                user.setEmail(email.getText().toString().trim());
                user.setGender(gender.getSelectedItem().toString());
                user.setPassword(md5(password.getText().toString().trim()));
                user.setPhone(phone.getText().toString().trim());
                user.setType("admin");

                if (!databaseHelper.checkUser(user.getEmail())){
                    databaseHelper.addUser(user);
                    //CharSequence text ="The Password after hasing"+ MD5_Hash_String;
                    int duration = Toast.LENGTH_LONG;
                    Toast toast = Toast.makeText(getActivity().getApplicationContext(), "Account created successfully", duration);
                    toast.show();
                }
                else{
                    int duration = Toast.LENGTH_LONG;
                    Toast toast = Toast.makeText(getActivity().getApplicationContext(), "Email is already used ...please enter another one!!", duration);
                    toast.show();
                }



                // TODO: Implement your own signup logic here.
                String string_to_be_converted_to_MD5 =confirmPassword.getText().toString();
                String MD5_Hash_String = md5(string_to_be_converted_to_MD5);



            }
        });




        return view;
    }
    public boolean validate(View view) {
        boolean valid = true;

        EditText firstName=(EditText)view.findViewById(R.id.firstNameFragment);
        EditText lastName=(EditText)view.findViewById(R.id.lastNameFragment);
        Spinner gender=(Spinner) view.findViewById(R.id.genderFragment);
        EditText email=(EditText)view.findViewById(R.id.emailFragment);
        EditText phone=(EditText)view.findViewById(R.id.mobileFragment);
        EditText password=(EditText)view.findViewById(R.id.passwordFragment);
        final EditText confirmPassword=(EditText)view.findViewById(R.id.confirmPasswordFragment);
        if (firstName.getText().toString().isEmpty() || firstName.getText().toString().length() < 3) {
            firstName.setError("at least 3 characters");
            valid = false;
        } else {
            firstName.setError(null);
        }
        if (lastName.getText().toString().isEmpty() || lastName.getText().toString().length() < 3) {
            lastName.setError("at least 3 characters");
            valid = false;
        } else {
            lastName.setError(null);
        }

        if (email.getText().toString().isEmpty() || !Patterns.EMAIL_ADDRESS.matcher(email.getText().toString()).matches()) {
            email.setError("enter a valid email address");
            valid = false;
        } else {
            email.setError(null);
        }

        if (phone.getText().toString().isEmpty() || phone.getText().toString().length()!=10 || !phone.getText().toString().startsWith("05")) {
            phone.setError("Enter Valid Mobile Number");
            valid = false;
        } else {
            phone.setError(null);
        }

        if (password.getText().toString().isEmpty() || password.getText().toString().length() < 8  || !(password.getText().toString().matches(".*[0-9].*")) ||  !(password.getText().toString().matches(".*[A-Z].*") ||  password.getText().toString().matches(".*[a-z].*") )) {
            password.setError("password must be at least 8 (charcter , numeric)");
            valid = false;
        } else {
            password.setError(null);
        }

        if (confirmPassword.getText().toString().isEmpty() || confirmPassword.getText().toString().length() < 8  || !(confirmPassword.getText().toString().equals(password.getText().toString()))) {
            confirmPassword.setError("Password Do not match");
            valid = false;
        } else {
            confirmPassword.setError(null);
        }


        return valid;
    }
    public String md5(String s) {
        try {
            // Create MD5 Hash
            MessageDigest digest = java.security.MessageDigest.getInstance("MD5");
            digest.update(s.getBytes());
            byte messageDigest[] = digest.digest();

            // Create Hex String
            StringBuffer hexString = new StringBuffer();
            for (int i=0; i<messageDigest.length; i++)
                hexString.append(Integer.toHexString(0xFF & messageDigest[i]));

            return hexString.toString();
        }catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        }
        return "";
    }


}
