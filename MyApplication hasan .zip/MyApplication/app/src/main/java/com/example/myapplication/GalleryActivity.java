package com.example.myapplication;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;


public class GalleryActivity extends AppCompatActivity {

    private static final String TAG = "GalleryActivity";
    private RadioGroup radioGroup;
    private RadioButton radioButton;
    private Button btnDisplay;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gallery);
        final DatabaseHelper databaseHelper=new DatabaseHelper(this);
        final User user=databaseHelper.getUser(CustomerActivity.emailRevived);
        Log.d(TAG, "onCreate: started.");
        getIncomingIntent();
        final Button cart = (Button) findViewById(R.id.cart);
        cart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {



                Toast.makeText(getApplicationContext(), "Product now is in you cart ",Toast.LENGTH_SHORT).show();

                databaseHelper.addOrder(user.getId(), Integer.parseInt(getIntent().getStringExtra("id")));

            }
        });

        final Button fav = (Button) findViewById(R.id.favarite);

        fav.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                Toast.makeText(getApplicationContext(), "Product now in you faivarite ",Toast.LENGTH_SHORT).show();
                databaseHelper.addFavourite(user.getId(),Integer.parseInt(getIntent().getStringExtra("id")));
            }
        });
    }

    private void getIncomingIntent(){
        Log.d(TAG, "getIncomingIntent: checking for incoming intents.");

        if(getIntent().hasExtra("image_url") && getIntent().hasExtra("image_name")){
            Log.d(TAG, "getIncomingIntent: found intent extras.");

            String imageUrl = getIntent().getStringExtra("image_url");
            String imageName = getIntent().getStringExtra("image_name");
            String Summary = getIntent().getStringExtra("summary");

            setImage(imageUrl, imageName,Summary);
        }
    }
    private void getIncomingIntent1(){
        Log.d(TAG, "getIncomingIntent: checking for incoming intents.");
        if(getIntent().hasExtra("image_url") && getIntent().hasExtra("image_name")){
            Log.d(TAG, "getIncomingIntent: found intent extras.");
            String imageName = getIntent().getStringExtra("image_name");
            setImage1(imageName);
        }
    }
    private void setImage1( String imageName){
        Log.d(TAG, "setImage: setting te image and name to widgets.");
        TextView name = findViewById(R.id.image_description);
        name.setText(imageName);
       // addListenerOnButton();
    }

    private void setImage(String imageUrl, String imageName,String summary){
        Log.d(TAG, "setImage: setting te image and name to widgets.");

        TextView name = findViewById(R.id.image_description);
        name.setText(imageName);

        ImageView image = findViewById(R.id.image);
        Glide.with(this)
                .asBitmap()
                .load(imageUrl)
                .into(image);


        //addListenerOnButton();

        TextView summary1 = findViewById(R.id.Summry);
        summary1.setText(summary);
    }

/*
    public void addListenerOnButton() {

        radioGroup = (RadioGroup) findViewById(R.id.radio);

        radioGroup .setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener()
        {
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                switch(checkedId){
                    case R.id.radio1:
                        // do operations specific to this selection
                        // Toast.makeText(GalleryActivity.this,
                        //  radioButton.getText(), Toast.LENGTH_SHORT).show();

                        break;
                    case R.id.radio2:
                        // do operations specific to this selection
                        //  Toast.makeText(GalleryActivity.this,
                        //         radioButton.getText(), Toast.LENGTH_SHORT).show();
                        break;
                    case R.id.radio3:
                        // do operations specific to this selection
                        //   Toast.makeText(GalleryActivity.this,
                        //        radioButton.getText(), Toast.LENGTH_SHORT).show();
                        break;
                }
            }
        });
    }
    */

}






















