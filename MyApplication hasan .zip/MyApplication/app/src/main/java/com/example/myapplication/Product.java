package com.example.myapplication;



public class Product {
    private int id;
    private String title;
    private String type;
    private String description;
    private String imageurl;
    private String height;
    private String width;
    private String price;
    private String rating;


    public Product(String title, String type, String description, String imageurl, String height, String width, String price, String rating) {
        this.title = title;
        this.type = type;
        this.description = description;
        this.imageurl = imageurl;
        this.height = height;
        this.width = width;
        this.price = price;
        this.rating = rating;

    }


    public Product() {
    }


    @Override
    public String toString() {
        return "Product{" +
                "title='" + title + '\'' +
                ", type='" + type + '\'' +
                ", description='" + description + '\'' +
                ", imageurl='" + imageurl + '\'' +
                ", height=" + height +
                ", width=" + width +
                ", price=" + price +
                ", rating=" + rating +
                '}';
    }
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getImageurl() {
        return imageurl;
    }

    public void setImageurl(String imageurl) {
        this.imageurl = imageurl;
    }

    public String getHeight() {
        return height;
    }

    public void setHeight(String height) {
        this.height = height;
    }

    public String getWidth() {
        return width;
    }

    public void setWidth(String width) {
        this.width = width;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getRating() {
        return rating;
    }

    public void setRating(String rating) {
        this.rating = rating;
    }




}

