package com.example.myapplication;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;

import java.util.ArrayList;


/**
 * A simple {@link Fragment} subclass.
 */
public class RecycleViewFragment extends Fragment {
    private static final String TAG = "MainActivity";
    private ArrayList<Product> list;
    //vars
    private ArrayList<String> mNames = new ArrayList<>();
    private ArrayList<String> mImageUrls = new ArrayList<>();
    private ArrayList<String> summry = new ArrayList<>();
    private ArrayList<String> id=new ArrayList<>();
    RecyclerViewAdapter adapter;
    RecyclerView recyclerView;
    public RecycleViewFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view=  inflater.inflate(R.layout.fragment_recycle_view, container, false);

        EditText name=(EditText) view.findViewById(R.id.name);
        name.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void afterTextChanged(Editable editable) {
                filter(editable.toString());
            }
        });





    list=new ArrayList<>();
        DatabaseHelper databaseHelper=new DatabaseHelper(getActivity());
        if(CustomerActivity.flag==1) {
            list = databaseHelper.getAllMenu();
        }
        else if(CustomerActivity.flag==2){
            ArrayList<Product> listTemp = databaseHelper.getAllMenu();
            for(int i=0; i< listTemp.size();++i){
                if( listTemp.get(i).getRating().matches("4") || listTemp.get(i).getRating().matches("5"))
                    list.add(listTemp.get(i));
            }
        }
        else{

            User user=databaseHelper.getUser(CustomerActivity.emailRevived);
            list= databaseHelper.favourite(user.getId());

        }

        Log.d(TAG, "initImageBitmaps: preparing bitmaps.");
        for(int i=0;i<list.size();++i) {
            mImageUrls.add(list.get(i).getImageurl());
            mNames.add(list.get(i).getTitle());
            summry.add(list.get(i).getDescription());
            id.add(list.get(i).getId()+"");
        }


        Log.d(TAG, "initRecyclerView: init recyclerview.");
         recyclerView = view.findViewById(R.id.recyclerv_view2);
        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
         adapter = new RecyclerViewAdapter(getActivity(), mNames, mImageUrls,summry,id);
        recyclerView.setAdapter(adapter);
        return view;
    }
    private void filter(String s) {
        ArrayList<String> url=new ArrayList<>();
        ArrayList<String> name=new ArrayList<>();
        ArrayList<String> id=new ArrayList<>();
        ArrayList<String> summary=new ArrayList<>();

        ArrayList<Product> filterdList = new ArrayList<>();
        for (Product product : list) {
            if (product.getTitle().toString().toLowerCase().contains(s.toLowerCase())) {
                url.add(product.getImageurl());
                name.add(product.getTitle());
                id.add(product.getId()+"");
                summary.add(product.getDescription());
            }
        }
        adapter.filterList((CustomerActivity) getActivity(),name,url,summry,id);

    }


}

