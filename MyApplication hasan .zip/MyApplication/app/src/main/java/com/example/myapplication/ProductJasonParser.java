
package com.example.myapplication;


import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.List;
public class ProductJasonParser {
    public static List<Product> getObjectFromJason(String jason) {
        List<Product> products;
        try {
            JSONArray jsonArray = new JSONArray(jason);
            products = new ArrayList<>();
            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject jsonObject = new JSONObject();
                jsonObject = (JSONObject) jsonArray.get(i);
                Product product = new Product();

                product.setTitle(jsonObject.getString("title"));
                product.setTitle(jsonObject.getString("type"));
                product.setDescription(jsonObject.getString("description"));
                product.setImageurl(jsonObject.getString("imageurl"));
                product.setHeight(jsonObject.getString("height"));
                product.setWidth(jsonObject.getString("width"));
                product.setRating(jsonObject.getString("rating"));
                product.setPrice(jsonObject.getString("price"));
                System.out.printf(product.toString()+"\n");

                products.add(product);


            }
        } catch (JSONException e) {
            e.printStackTrace();
            return null;
        }
        return products;
    }
}
