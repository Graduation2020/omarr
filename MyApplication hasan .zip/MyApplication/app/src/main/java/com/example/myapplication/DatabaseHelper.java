package com.example.myapplication;

import android.database.sqlite.SQLiteOpenHelper;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class DatabaseHelper extends SQLiteOpenHelper {

    int results;

    //private static final String DATABASE_NAME = "UserManager.db";
    // User table name
    private static final String TABLE_USER = "user";

    // User Table Columns names
    private static final String COLUMN_USER_ID = "user_id";
    private static final String COLUMN_USER_FIRST_NAME = "user_first_name";
    private static final String COLUMN_USER_LAST_NAME = "user_last_name";
    private static final String COLUMN_USER_EMAIL = "user_email";
    private static final String COLUMN_USER_PHONE = "user_phone";
    private static final String COLUMN_USER_PASSWORD = "user_password";
    private static final String COLUMN_USER_GENDER = "user_gender";
    private static final String COLUMN_USER_TYPE = "user_type";


    //private static final String TABLE_MENU = "user";

    public static final String TABLE_MENU = "menu";

    public static final String COLUMN_ID = "menu_id";
    public static final String COLUMN_TITLE = "title";
    public static final String COLUMN_DESCRIPTION = "description";
    public static final String COLUMN_HEIGHT = "height";
    public static final String COLUMN_WIDTH = "width";
    public static final String COLUMN_PRICE = "price";
    public static final String COLUMN_RATING = "rating";
    public static final String COLUMN_OFFER = "offer";
    public static final String COLUMN_TYPE = "type";
    public static final String COLUMN_IMAGEURL = "imageurl";


    // create table sql query
    private String CREATE_MENU_TABLE = "CREATE TABLE " + TABLE_MENU + "("
            + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT," +
            COLUMN_TITLE + " TEXT," +
            COLUMN_HEIGHT + " TEXT," +
            COLUMN_WIDTH + " TEXT," +
            COLUMN_PRICE + " TEXT," +
            COLUMN_RATING + " TEXT," +
            COLUMN_DESCRIPTION + " TEXT," +
            COLUMN_IMAGEURL + " TEXT," +
            COLUMN_TYPE + " TEXT" + ")";

    private String CREATE_USER_TABLE = "CREATE TABLE " + TABLE_USER + "("
            + COLUMN_USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT," +
            COLUMN_USER_FIRST_NAME + " TEXT," +
            COLUMN_USER_LAST_NAME + " TEXT," +
            COLUMN_USER_EMAIL + " TEXT," +
            COLUMN_USER_PHONE + " TEXT," +
            COLUMN_USER_PASSWORD + " TEXT," +
            COLUMN_USER_GENDER + " TEXT," +
            COLUMN_USER_TYPE + " TEXT" + ")";


    public DatabaseHelper(Context context) {
        super(context, "Pizza_Shop", null, 1);
    }


    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_USER_TABLE);
        db.execSQL(CREATE_MENU_TABLE);
        String tableOrder = "CREATE TABLE orders( customerId  INTEGER, menuId INTEGER, date TEXT, FOREIGN KEY(customerId) REFERENCES user(user_id) , FOREIGN KEY(menuId) REFERENCES menu(menu_id),PRIMARY KEY(customerId,menuId,date))";
        String tableFavourite = "CREATE TABLE favourites( customerId  INTEGER, menuId INTEGER, FOREIGN KEY(customerId) REFERENCES user(user_id) , FOREIGN KEY(menuId) REFERENCES menu(menu_id),PRIMARY KEY(customerId,menuId))";

        db.execSQL(tableOrder);
        db.execSQL(tableFavourite);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {


    }

    void dropTables() {

        SQLiteDatabase db = this.getWritableDatabase();
        // delete user record by id
        // db.delete(TABLE_USER, null,null);
        db.delete(TABLE_MENU, null, null);
        //db.execSQL("DROP TABLE menu");
        //db.execSQL(CREATE_MENU_TABLE);
        db.close();

    }



    public boolean addUser(User user) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_USER_FIRST_NAME, user.getFirstName());
        values.put(COLUMN_USER_LAST_NAME, user.getLastName());
        values.put(COLUMN_USER_EMAIL, user.getEmail());
        values.put(COLUMN_USER_PHONE, user.getPhone());
        values.put(COLUMN_USER_PASSWORD, user.getPassword());
        values.put(COLUMN_USER_GENDER, user.getGender());
        values.put(COLUMN_USER_TYPE, user.getType());

        // Inserting Row

        long result = db.insert(TABLE_USER, null, values);

        if (results == -1)
            return false;
        else
            return true;
    }

    public boolean addMenu(Product product) {

        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_TITLE, product.getTitle());
        values.put(COLUMN_DESCRIPTION, product.getDescription());
        values.put(COLUMN_TYPE, product.getType());
        values.put(COLUMN_IMAGEURL, product.getImageurl());
        values.put(COLUMN_HEIGHT, product.getHeight());
        values.put(COLUMN_WIDTH, product.getWidth());
        values.put(COLUMN_PRICE, product.getPrice());
        values.put(COLUMN_RATING, product.getPrice());

        // Inserting Row
        long result = db.insert(TABLE_MENU, null, values);
        if (results == -1)
            return false;
        else
            return true;
    }


    /////////////////
    /////////////////



    public Cursor getAllUser_() {

        String[] columns = {
                COLUMN_USER_ID,
                COLUMN_USER_EMAIL,
                COLUMN_USER_FIRST_NAME,
                COLUMN_USER_LAST_NAME,
                COLUMN_USER_PHONE,
                COLUMN_USER_PASSWORD,
                COLUMN_USER_GENDER
        };

        ////

        // sorting orders
        String sortOrder =
                COLUMN_USER_FIRST_NAME + " ASC";
        List<User> userList = new ArrayList<User>();

        SQLiteDatabase db = this.getReadableDatabase();


        Cursor cursor = db.query(TABLE_USER, //Table to query
                columns,    //columns to return
                null,        //columns for the WHERE clause
                null,        //The values for the WHERE clause
                null,       //group the rows
                null,       //filter by row groups
                sortOrder); //The sort order

        return cursor;


    }


    //////////////////////
    public Product getMenuByID(int id) {

        String[] columns = {

                COLUMN_ID,
                COLUMN_TYPE,
                COLUMN_TITLE,
                COLUMN_DESCRIPTION,
                COLUMN_TYPE,
                COLUMN_OFFER,
                COLUMN_IMAGEURL,
                COLUMN_HEIGHT,
                COLUMN_WIDTH,
                COLUMN_PRICE,
                COLUMN_RATING
        };


        SQLiteDatabase db = this.getReadableDatabase();
        String selection = COLUMN_ID + " = ?";

        // selection arguments
        String[] selectionArgs = {id + ""};
        // query the user table

        Cursor cursor = db.query(TABLE_MENU, //Table to query
                columns,    //columns to return
                selection,        //columns for the WHERE clause
                selectionArgs,        //The values for the WHERE clause
                null,       //group the rows
                null,       //filter by row groups
                null); //The sort order
        if (cursor.moveToFirst()) {
            Product product = new Product();

            product.setId(Integer.parseInt(cursor.getString(cursor.getColumnIndex(COLUMN_ID))));
            product.setType(cursor.getString(cursor.getColumnIndex(COLUMN_TYPE)));
            product.setDescription(cursor.getString(cursor.getColumnIndex(COLUMN_DESCRIPTION)));
            product.setTitle(cursor.getString(cursor.getColumnIndex(COLUMN_TITLE)));
            product.setHeight(cursor.getString(cursor.getColumnIndex(COLUMN_HEIGHT)));
            product.setWidth(cursor.getString(cursor.getColumnIndex(COLUMN_WIDTH)));
            product.setType(cursor.getString(cursor.getColumnIndex(COLUMN_TYPE)));
            product.setImageurl(cursor.getString(cursor.getColumnIndex(COLUMN_IMAGEURL)));
            product.setPrice(cursor.getString(cursor.getColumnIndex(COLUMN_PRICE)));
            product.setRating(cursor.getString(cursor.getColumnIndex(COLUMN_RATING)));
            return product;
        }


        return null;
    }


    ////////////
    /////////


    public ArrayList<Product> getAllMenu() {
        ArrayList<Product> menu = new ArrayList<Product>();
        String[] columns = {
                COLUMN_ID,
                COLUMN_TYPE,
                COLUMN_TITLE,
                COLUMN_DESCRIPTION,
                COLUMN_TYPE,
                COLUMN_OFFER,
                COLUMN_IMAGEURL,
                COLUMN_HEIGHT,
                COLUMN_WIDTH,
                COLUMN_PRICE,
                COLUMN_RATING
        };
        // sorting orders
        String sortOrder =
                COLUMN_TITLE + " ASC";
        List<Product> productList = new ArrayList<Product>();

        SQLiteDatabase db = this.getReadableDatabase();
    Cursor cursor = db.query(TABLE_MENU, //Table to query
                columns,    //columns to return
                null,        //columns for the WHERE clause
                null,        //The values for the WHERE clause
                null,       //group the rows
                null,       //filter by row groups
                sortOrder); //The sort order
        if (cursor.moveToFirst()) {
            do {
            Product product = new Product();

            product.setId(Integer.parseInt(cursor.getString(cursor.getColumnIndex(COLUMN_ID))));
            product.setType(cursor.getString(cursor.getColumnIndex(COLUMN_TYPE)));
            product.setDescription(cursor.getString(cursor.getColumnIndex(COLUMN_DESCRIPTION)));
            product.setTitle(cursor.getString(cursor.getColumnIndex(COLUMN_TITLE)));
            product.setHeight((cursor.getString(cursor.getColumnIndex(COLUMN_HEIGHT))));
            product.setWidth((cursor.getString(cursor.getColumnIndex(COLUMN_WIDTH))));
            product.setType(cursor.getString(cursor.getColumnIndex(COLUMN_TYPE)));
            product.setImageurl(cursor.getString(cursor.getColumnIndex(COLUMN_IMAGEURL)));
            product.setPrice((cursor.getString(cursor.getColumnIndex(COLUMN_PRICE))));
            product.setRating((cursor.getString(cursor.getColumnIndex(COLUMN_RATING))));

            menu.add(product);
        }
        while (cursor.moveToNext()) ;

    }
        return menu;
}



    public List<User> getAllUser() {
        // array of columns to fetch
        String[] columns = {
                COLUMN_USER_ID,
                COLUMN_USER_EMAIL,
                COLUMN_USER_FIRST_NAME,
                COLUMN_USER_LAST_NAME,
                COLUMN_USER_PHONE,
                COLUMN_USER_PASSWORD,
                COLUMN_USER_GENDER,
                COLUMN_USER_TYPE
        };
        // sorting orders
        String sortOrder =
                COLUMN_USER_FIRST_NAME + " ASC";
        List<User> userList = new ArrayList<User>();

        SQLiteDatabase db = this.getReadableDatabase();

      Cursor cursor = db.query(TABLE_USER, //Table to query
                columns,    //columns to return
                null,        //columns for the WHERE clause
                null,        //The values for the WHERE clause
                null,       //group the rows
                null,       //filter by row groups
                sortOrder); //The sort order


        // Traversing through all rows and adding to list
        if (cursor.moveToFirst()) {
            do {
                User user = new User();
                user.setId(Integer.parseInt(cursor.getString(cursor.getColumnIndex(COLUMN_USER_ID))));
                user.setFirstName(cursor.getString(cursor.getColumnIndex(COLUMN_USER_FIRST_NAME)));
                user.setLastName(cursor.getString(cursor.getColumnIndex(COLUMN_USER_LAST_NAME)));
                user.setEmail(cursor.getString(cursor.getColumnIndex(COLUMN_USER_EMAIL)));
                user.setPhone(cursor.getString(cursor.getColumnIndex(COLUMN_USER_PHONE)));
                user.setPassword(cursor.getString(cursor.getColumnIndex(COLUMN_USER_PASSWORD)));
                user.setGender(cursor.getString(cursor.getColumnIndex(COLUMN_USER_GENDER)));
                user.setType(cursor.getString(cursor.getColumnIndex(COLUMN_USER_TYPE)));
                // Adding user record to list
                userList.add(user);
            } while (cursor.moveToNext());
        }
        cursor.close();
        db.close();

        // return user list
        return userList;
    }


    /////////////////////
    ///////////////////
    /////////////////
    ///////////////
    ////////////





     public void updateUser(User user) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_USER_FIRST_NAME, user.getFirstName());
        values.put(COLUMN_USER_LAST_NAME, user.getLastName());
        values.put(COLUMN_USER_PHONE, user.getPhone());

        values.put(COLUMN_USER_PASSWORD, user.getPassword());
        // updating row
        db.update(TABLE_USER, values, COLUMN_USER_EMAIL + " = ?",
                new String[]{});
        db.close();
    }

    public boolean updateData(String email, String firstName, String lastName, String password, String phone) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COLUMN_USER_PASSWORD,password);
        contentValues.put(COLUMN_USER_PHONE,phone);
        contentValues.put(COLUMN_USER_FIRST_NAME,firstName);
        contentValues.put(COLUMN_USER_LAST_NAME,lastName);

        db.update(TABLE_USER, contentValues, COLUMN_USER_EMAIL+ " = ?",new String[] { email });
        return true;

    }

    public void updatePassword(String email, String password){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_USER_PASSWORD, password);
        db.update(TABLE_USER, values, COLUMN_USER_EMAIL+" = ?",new String[] { email });
        db.close();
    }
     public void deleteUser(User user) {
        SQLiteDatabase db = this.getWritableDatabase();
        // delete user record by id
        db.delete(TABLE_USER, COLUMN_USER_ID + " = ?",
                new String[]{String.valueOf(user.getId())});
        db.close();
    }
    public Integer deleteuserData (String id) {
        SQLiteDatabase db = this.getWritableDatabase();
        return db.delete(TABLE_USER, COLUMN_USER_ID + " = ?",new String[] {id});
    }


    public boolean checkUser(String email) {

        // array of columns to fetch
        String[] columns = {
                COLUMN_USER_ID
        };
        SQLiteDatabase db = this.getReadableDatabase();

        // selection criteria
        String selection = COLUMN_USER_EMAIL + " = ?";

        // selection argument
        String[] selectionArgs = {email};


        Cursor cursor = db.query(TABLE_USER, //Table to query
                columns,                    //columns to return
                selection,                  //columns for the WHERE clause
                selectionArgs,              //The values for the WHERE clause
                null,                       //group the rows
                null,                      //filter by row groups
                null);                      //The sort order
        int cursorCount = cursor.getCount();
        cursor.close();
        db.close();

        if (cursorCount > 0) {
            return true;
        }

        return false;
    }



    public boolean checkUser(String email, String password) {
        // array of columns to fetch
        String[] columns = {
                COLUMN_USER_ID
        };
        SQLiteDatabase db = this.getReadableDatabase();
        // selection criteria
        String selection = COLUMN_USER_EMAIL + " = ?" + " AND " + COLUMN_USER_PASSWORD + " = ?";

        // selection arguments
        String[] selectionArgs = {email, password};


        Cursor cursor = db.query(TABLE_USER, //Table to query
                columns,                    //columns to return
                selection,                  //columns for the WHERE clause
                selectionArgs,              //The values for the WHERE clause
                null,                       //group the rows
                null,                       //filter by row groups
                null);                      //The sort order

        int cursorCount = cursor.getCount();

        cursor.close();
        db.close();
        if (cursorCount > 0) {
            return true;
        }

        return false;
    }

    public boolean userType(String email,String type) {
        // array of columns to fetch
        String[] columns = {
                COLUMN_USER_ID
        };
        SQLiteDatabase db = this.getReadableDatabase();
        // selection criteria
        String selection = COLUMN_USER_EMAIL + " = ?" + " AND " + COLUMN_USER_TYPE + " = ?";

        // selection arguments
        String[] selectionArgs = {email,type};


        Cursor cursor = db.query(TABLE_USER, //Table to query
                columns,                    //columns to return
                selection,                  //columns for the WHERE clause
                selectionArgs,              //The values for the WHERE clause
                null,                       //group the rows
                null,                       //filter by row groups
                null);                      //The sort order

        int cursorCount = cursor.getCount();

        cursor.close();
        db.close();
        if (cursorCount > 0) {
            return true;
        }

        return false;
    }
    ///////////
    ///////////////
    /////////////////////
    ////////////////////////////
    /////////////////////////////////


    /////////////////////////////////
    /////////////////////////
    ////////////////////



    public boolean addOrder(int customerId,int menuId){
        DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
        Date date = new Date();
        String dateTime=dateFormat.format(date);
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("customerId", customerId);
        values.put("menuId", menuId);
        values.put("date", dateTime);

        // Inserting Row

        long result = db.insert("orders", null, values);

        if(results == -1)
            return false;
        else
            return true;



    }

    public User getUserById(int id) {
        String[] columns = {
                COLUMN_USER_ID,
                COLUMN_USER_EMAIL,
                COLUMN_USER_FIRST_NAME,
                COLUMN_USER_LAST_NAME,
                COLUMN_USER_PHONE,
                COLUMN_USER_PASSWORD,
                COLUMN_USER_GENDER,
                COLUMN_USER_TYPE
        };
        String selection = COLUMN_USER_ID + " = ?";

        // selection arguments
        String[] selectionArgs = {id+""};




        SQLiteDatabase db = this.getReadableDatabase();

        // query the user table

        Cursor cursor = db.query(TABLE_USER, //Table to query
                columns,    //columns to return
                selection,        //columns for the WHERE clause
                selectionArgs,        //The values for the WHERE clause
                null,       //group the rows
                null,       //filter by row groups
                null); //The sort order


        // Traversing through all rows and adding to list
        if( cursor.moveToFirst()) {

            User user = new User();
            user.setId(Integer.parseInt(cursor.getString(cursor.getColumnIndex(COLUMN_USER_ID))));
            user.setFirstName(cursor.getString(cursor.getColumnIndex(COLUMN_USER_FIRST_NAME)));
            user.setLastName(cursor.getString(cursor.getColumnIndex(COLUMN_USER_LAST_NAME)));
            user.setEmail(cursor.getString(cursor.getColumnIndex(COLUMN_USER_EMAIL)));
            user.setPhone(cursor.getString(cursor.getColumnIndex(COLUMN_USER_PHONE)));
            user.setPassword(cursor.getString(cursor.getColumnIndex(COLUMN_USER_PASSWORD)));
            user.setGender(cursor.getString(cursor.getColumnIndex(COLUMN_USER_GENDER)));
            user.setType(cursor.getString(cursor.getColumnIndex(COLUMN_USER_TYPE)));

            cursor.close();
            db.close();

            // return user list
            return user;
        }
        return null;

    }
    public User getUser(String emailRevived) {
        String[] columns = {
                COLUMN_USER_ID,
                COLUMN_USER_EMAIL,
                COLUMN_USER_FIRST_NAME,
                COLUMN_USER_LAST_NAME,
                COLUMN_USER_PHONE,
                COLUMN_USER_PASSWORD,
                COLUMN_USER_GENDER,
                COLUMN_USER_TYPE
        };
        String selection = COLUMN_USER_EMAIL + " = ?";

        // selection arguments
        String[] selectionArgs = {emailRevived};




        SQLiteDatabase db = this.getReadableDatabase();

        // query the user table

        Cursor cursor = db.query(TABLE_USER, //Table to query
                columns,    //columns to return
                selection,        //columns for the WHERE clause
                selectionArgs,        //The values for the WHERE clause
                null,       //group the rows
                null,       //filter by row groups
                null); //The sort order


        // Traversing through all rows and adding to list
        cursor.moveToFirst();
        User user = new User();
        user.setId(Integer.parseInt(cursor.getString(cursor.getColumnIndex(COLUMN_USER_ID))));
        user.setFirstName(cursor.getString(cursor.getColumnIndex(COLUMN_USER_FIRST_NAME)));
        user.setLastName(cursor.getString(cursor.getColumnIndex(COLUMN_USER_LAST_NAME)));
        user.setEmail(cursor.getString(cursor.getColumnIndex(COLUMN_USER_EMAIL)));
        user.setPhone(cursor.getString(cursor.getColumnIndex(COLUMN_USER_PHONE)));
        user.setPassword(cursor.getString(cursor.getColumnIndex(COLUMN_USER_PASSWORD)));
        user.setGender(cursor.getString(cursor.getColumnIndex(COLUMN_USER_GENDER)));
        user.setType(cursor.getString(cursor.getColumnIndex(COLUMN_USER_TYPE)));

        cursor.close();
        db.close();

        // return user list
        return user;

    }
    public ArrayList<Order> getOrders(){
        ArrayList<Order> orders =new ArrayList<Order>();
        // array of columns to fetch
        String[] columns = {
                "customerId",
                "menuId",
                "date"

        };



        SQLiteDatabase db = this.getReadableDatabase();

        // query the user table

        Cursor cursor = db.query("orders", //Table to query
                columns,    //columns to return
                null,        //columns for the WHERE clause
                null,        //The values for the WHERE clause
                null,       //group the rows
                null,       //filter by row groups
                null); //The sort order



        // Traversing through all rows and adding to list
        if (cursor.moveToFirst()) {
            do {
                Order order = new Order();
                order.setCustomerId(Integer.parseInt(cursor.getString(cursor.getColumnIndex("customerId"))));
                order.setMenuId(Integer.parseInt(cursor.getString(cursor.getColumnIndex("menuId"))));
                order.setDate(cursor.getString(cursor.getColumnIndex("date")));

                // Adding user record to list
                orders.add(order);
            } while (cursor.moveToNext());
        }
        cursor.close();
        db.close();

        // return user list
        return orders;

    }
    public boolean addFavourite(int customerId,int menuId){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("customerId", customerId);
        values.put("menuId", menuId);


        // Inserting Row

        long result = db.insert("favourites", null, values);

        if(results == -1)
            return false;
        else
            return true;


    }

    public ArrayList<Product> favourite(int idUser) {

        ArrayList<Product> favouriteList = new ArrayList<Product>();

        String customerId="customerId";
        String menuId="menuId";
        String[] columns = {
                customerId,
                menuId
        };
        String selection = customerId + " = ?";

        // selection arguments
        String[] selectionArgs = {idUser+""};



        SQLiteDatabase db = this.getReadableDatabase();

        // query the user table

        Cursor cursor = db.query("favourites", //Table to query
                columns,    //columns to return
                selection,        //columns for the WHERE clause
                selectionArgs,        //The values for the WHERE clause
                null,       //group the rows
                null,       //filter by row groups
                null); //The sort order



        // Traversing through all rows and adding to list
        if (cursor.moveToFirst()) {
            do {
                if(Integer.parseInt(cursor.getString(cursor.getColumnIndex("customerId"))) == idUser) {

                   Product product =this.getMenuByID(Integer.parseInt(cursor.getString(cursor.getColumnIndex("menuId"))));

                    favouriteList.add(product);
                }
            } while (cursor.moveToNext());

        }
        return favouriteList;
    }
    //////////
    ///////////////////////
    /////////////////////////////
    ///////////////////////////////////


    public ArrayList<User> getAllCustomers() {
        ArrayList<User> userList=new ArrayList<User>();
        String[] columns = {
                COLUMN_USER_ID,
                COLUMN_USER_EMAIL,
                COLUMN_USER_FIRST_NAME,
                COLUMN_USER_LAST_NAME,
                COLUMN_USER_PHONE,
                COLUMN_USER_PASSWORD,
                COLUMN_USER_GENDER,
                COLUMN_USER_TYPE
        };
        String selection = COLUMN_USER_TYPE + " = ?";

        // selection arguments
        String[] selectionArgs = {"customer"};




        SQLiteDatabase db = this.getReadableDatabase();

        // query the user table

        Cursor cursor = db.query(TABLE_USER, //Table to query
                columns,    //columns to return
                selection,        //columns for the WHERE clause
                selectionArgs,        //The values for the WHERE clause
                null,       //group the rows
                null,       //filter by row groups
                null); //The sort order


        // Traversing through all rows and adding to list
        if (cursor.moveToFirst()) {
            do {
                User user = new User();
                user.setId(Integer.parseInt(cursor.getString(cursor.getColumnIndex(COLUMN_USER_ID))));
                user.setFirstName(cursor.getString(cursor.getColumnIndex(COLUMN_USER_FIRST_NAME)));
                user.setLastName(cursor.getString(cursor.getColumnIndex(COLUMN_USER_LAST_NAME)));
                user.setEmail(cursor.getString(cursor.getColumnIndex(COLUMN_USER_EMAIL)));
                user.setPhone(cursor.getString(cursor.getColumnIndex(COLUMN_USER_PHONE)));
                user.setPassword(cursor.getString(cursor.getColumnIndex(COLUMN_USER_PASSWORD)));
                user.setGender(cursor.getString(cursor.getColumnIndex(COLUMN_USER_GENDER)));
                user.setType(cursor.getString(cursor.getColumnIndex(COLUMN_USER_TYPE)));
                // Adding user record to list
                userList.add(user);
            } while (cursor.moveToNext());
        }
        cursor.close();
        db.close();

        // return user list
        return userList;
    }

    public void updateMenuId(int id){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        int newId=id%10;
        if(newId==0)
            newId=10;
        values.put(COLUMN_ID, newId);

        db.update(TABLE_MENU, values, COLUMN_ID+" = ?",new String[] { id+"" });
        db.close();
    }



    //////////////////
    ///////////////////////
    //////////////////////////
    ////////////////////////////////




}