package com.example.myapplication;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.util.Patterns;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import butterknife.BindView;
import butterknife.ButterKnife;

public class SignupActivity extends AppCompatActivity {
    private static final String TAG = "SignupActivity";

    @BindView(R.id.firstName)
    EditText _firstNameText;
    @BindView(R.id.lastName)
    EditText _lastNameText;
    @BindView(R.id.email)
    EditText _emailText;
    @BindView(R.id.mobile)
    EditText _mobileText;
    @BindView(R.id.password)
    EditText _passwordText;
    @BindView(R.id.confirmPassword)
    EditText _reEnterPasswordText;
    @BindView(R.id.button_sgnup)
    Button _signupButton;
    @BindView(R.id.link_login)
    TextView _loginLink;
    @BindView(R.id.gender)
    Spinner _gender;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);
        ButterKnife.bind(this);
        String[] options = { "Male", "Female"};
                ArrayAdapter objGenderArr = new ArrayAdapter
                (this,android.R.layout.simple_spinner_item, options);
        _gender.setAdapter(objGenderArr);
_gender.setSelection(0);
        _signupButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                signup();
            }
        });

        _loginLink.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Finish the registration screen and return to the Login activity
                Intent intent = new Intent(getApplicationContext(),LoginActivity.class);
                startActivity(intent);
                finish();
                overridePendingTransition(R.anim.push_left_in, R.anim.push_left_out);
            }
        });
    }

    public void signup() {
        Log.d(TAG, "Signup");

        if (!validate()) {
            onSignupFailed();
            return;
        }

        _signupButton.setEnabled(false);

        final ProgressDialog progressDialog = new ProgressDialog(SignupActivity.this,
                R.style.AppTheme_Dark_Dialog);
        progressDialog.setIndeterminate(true);
        progressDialog.setMessage("Creating Account...");
        progressDialog.show();

        String firstName = _firstNameText.getText().toString();
        String lastname = _lastNameText.getText().toString();
        String email = _emailText.getText().toString();
        String mobile = _mobileText.getText().toString();
        String password = _passwordText.getText().toString();
        String reEnterPassword = _reEnterPasswordText.getText().toString();
        String gender= _gender.getSelectedItem().toString();


        // TODO: Implement your own signup logic here.
        String string_to_be_converted_to_MD5 =_reEnterPasswordText.getText().toString();
        String MD5_Hash_String = md5(string_to_be_converted_to_MD5);


        final DatabaseHelper databaseHelper=new DatabaseHelper(this);

        new android.os.Handler().postDelayed(
                new Runnable() {
                    public void run() {

                        // On complete call either onSignupSuccess or onSignupFailed
                        // depending on success
                        if (!databaseHelper.checkUser(_emailText.getText().toString().trim())) {


                            onSignupSuccess();
                        }
                        else {
                            Toast.makeText(getBaseContext(), "Email is already use please choose another one !!", Toast.LENGTH_LONG).show();
                            _signupButton.setEnabled(true);
                        }
                        progressDialog.dismiss();
                    }
                }, 3000);
    }


    public void onSignupSuccess() {
        _signupButton.setEnabled(true);
        setResult(RESULT_OK, null);
     //   finish();
        User user =new User();
        DatabaseHelper databaseHelper=new DatabaseHelper(this);
        user.setFirstName(_firstNameText.getText().toString().trim());
        user.setLastName(_lastNameText.getText().toString().trim());
        user.setEmail(_emailText.getText().toString().trim());
        user.setPassword(md5(_passwordText.getText().toString().trim()));
        user.setPhone(_mobileText.getText().toString().trim());
        user.setGender(_gender.getSelectedItem().toString().trim());
        user.setType("customer");
        databaseHelper.addUser(user);
        Context context = getApplicationContext();
        //CharSequence text ="The Password after hasing"+ MD5_Hash_String;
        int duration = Toast.LENGTH_LONG;
        Toast toast = Toast.makeText(context, "Sign Up Succefully", duration);
        toast.show();
        Intent intent = new Intent(getApplicationContext(),CustomerActivity.class);
        intent.putExtra("EMAIL", _emailText.getText().toString().trim());
        startActivity(intent);
        finish();
        overridePendingTransition(R.anim.push_left_in, R.anim.push_left_out);
        // Snack Bar to show success message that record saved successfully
    }

    public void onSignupFailed() {
        Toast.makeText(getBaseContext(), "Login failed", Toast.LENGTH_LONG).show();

        _signupButton.setEnabled(true);
    }

    public boolean validate() {
        boolean valid = true;

        String firstName = _firstNameText.getText().toString();
        String lastname = _lastNameText.getText().toString();
        String gender= _gender.getSelectedItem().toString();
        String email = _emailText.getText().toString();
        String mobile = _mobileText.getText().toString();
        String password = _passwordText.getText().toString();
        String reEnterPassword = _reEnterPasswordText.getText().toString();

        if (firstName.isEmpty() || firstName.length() < 3) {
            _firstNameText.setError("at least 3 characters");
            valid = false;
        } else {
            _firstNameText.setError(null);
        }
        if (lastname.isEmpty() || lastname.length() < 3) {
            _lastNameText.setError("at least 3 characters");
            valid = false;
        } else {
            _lastNameText.setError(null);
        }

        if (email.isEmpty() || !Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            _emailText.setError("enter a valid email address");
            valid = false;
        } else {
            _emailText.setError(null);
        }

        if (mobile.isEmpty() || mobile.length()!=10 || !mobile.startsWith("05")) {
            _mobileText.setError("Enter Valid Mobile Number");
            valid = false;
        } else {
            _mobileText.setError(null);
        }

        if (password.isEmpty() || password.length() < 8  || !(password.matches(".*[0-9].*")) ||  !(password.matches(".*[A-Z].*") ||  password.matches(".*[a-z].*") )) {
            _passwordText.setError("password must be at least 8 (charcter , numeric)");
            valid = false;
        } else {
            _passwordText.setError(null);
        }

        if (reEnterPassword.isEmpty() || reEnterPassword.length() < 8  || !(reEnterPassword.equals(password))) {
            _reEnterPasswordText.setError("Password Do not match");
            valid = false;
        } else {
            _reEnterPasswordText.setError(null);
        }


        return valid;
    }
    public String md5(String s) {
        try {
            // Create MD5 Hash
            MessageDigest digest = java.security.MessageDigest.getInstance("MD5");
            digest.update(s.getBytes());
            byte messageDigest[] = digest.digest();

            // Create Hex String
            StringBuffer hexString = new StringBuffer();
            for (int i=0; i<messageDigest.length; i++)
                hexString.append(Integer.toHexString(0xFF & messageDigest[i]));

            return hexString.toString();
        }catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        }
        return "";
    }
    private void emptyInputEditText() {
        _mobileText.setText(null);
        _passwordText.setText(null);
        _reEnterPasswordText.setText(null);
        _lastNameText.setText(null);
        _firstNameText.setText(null);
        _gender.setSelection(0);

    }
}